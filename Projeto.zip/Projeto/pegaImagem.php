<?php
	if (isset($_SESSION['cor'])) {
		unset($_SESSION['cor']);
	}
	if(!isset($_POST['exampleRadios'])){
		exit();
		header('LOCATION: pulseiraIndex.php');
	}
	if($_POST['exampleRadios'] == "preto") {
		$_SESSION['cor'] = "<img src='imagens/pulseiraPreta.jpg' class='figure-img img-fluid rounded' alt='...''>";
	} elseif ($_POST['exampleRadios'] == "vermelho") {
		$_SESSION['cor'] = "<img src='imagens/pulseiraVermelha.jpg' class='figure-img img-fluid rounded' alt='...''>";
	} elseif ($_POST['exampleRadios'] == "verdeAqua") {
		$_SESSION['cor'] = "<img src='imagens/pulseiraVerde.jpg' class='figure-img img-fluid rounded' alt='...''>";
	} elseif ($_POST['exampleRadios'] == "azulNoturno") {
		$_SESSION['cor'] = "<img src='imagens/pulseiraAzulNoturno.jpg' class='figure-img img-fluid rounded' alt='...''>";
	} elseif ($_POST['exampleRadios'] == "azulAco") {
		$_SESSION['cor'] = "<img src='imagens/pulseiraAzulAco.jpg' class='figure-img img-fluid rounded' alt='...''>";
	}
?>