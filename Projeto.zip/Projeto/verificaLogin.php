<?php
    if(!$_SESSION['login']){
      header('LOCATION: loginIndex.php');
      exit();
    }
  ?>