<!DOCTYPE html>

<html>

<head>

	<script src="https://kit.fontawesome.com/f48515887e.js" crossorigin="anonymous"></script>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">


	<link rel="stylesheet" type="text/css" href="indexcss.css">

	<meta charset="utf-8">

	<title>JKLM Helper</title>
  <style type="text/css">
    body {
      font-family: 'Montserrat', sans-serif;
    }
  </style>

</head>
<?php include 'login.php';
?>
<body style="background-color: lightgrey;">
	<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #45c087">
  <a class="navbar-brand" href="index.php">JKLM Helper</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Início<span class="sr-only">(current)</span></a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">
        Contato
        </a>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Sobre
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="#">Como funciona</a>
              <a class="dropdown-item" href="#">Benefícios</a>
              <a class="dropdown-item" href="#">Onde encontrar?</a>
            </div>
          </li>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Produtos
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="pulseiraIndex.php">Pulseira</a>
          <a class="dropdown-item" href="#">Planos</a>
        </div>
      </li>
      <?php if(!isset($_SESSION['login'])):?>
      <li class="nav-item dropdown" >
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Entrar
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="loginIndex.php" >Logar</a>
          <a class="dropdown-item" href="cadastroIndex.php">Cadastrar-se</a>
        </div>
      </li>
      <?php endif;?>
      <?php if(isset($_SESSION['login'])):?>
      <li class="nav-item dropdown">  
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <?php   echo $_SESSION['nomeResponsavel']?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="cadastroIdosoIndex.php">Cadastrar idoso</a>
          <a class="dropdown-item" href="#" >Editar meus dados</a>
          <a class="dropdown-item" href="#">Ver meu plano</a>
        </div>
      </li>
      <!--Botao logout -->
      <li class="nav-item" style="margin-top:5px" >
        <form action="logOut.php">  
          <button type="submit"style="background-color: transparent; border-color: transparent;"><i class="fa fa-sign-out" style="font-size:24px; color: white;"></i></button>
        </form>
      </li>
      <?php endif ?>
    </ul>
  </div>
  </nav>

  <nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Início</a></li>
    <li class="breadcrumb-item active" aria-current="page">Cadastro</li>
  </ol>
</nav>

	<div class="container" style="background-color: #45C087; padding-bottom: 20px;">
	<form method="post" action="cadastro.php">
  <div class="form-row">
  	<div class="form-group col-md-4">
    <label for="inputAddress">Nome</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="Usuário" style="background-color: #CCFFDC;" name="nome">
  </div>
    <div class="form-group col-md-4">
      <label for="inputEmail4">Email</label>
      <input type="email" class="form-control" id="inputEmail4" placeholder="Email" style="background-color: #CCFFDC;" name="email">
    </div>
    <div class="form-group col-md-4">
      <label for="inputPassword4">Senha</label>
      <input type="password" class="form-control" id="inputPassword4" placeholder="Senha" style="background-color: #CCFFDC;" name="senha">
    </div>
  </div>
  <label for="inputAddress2">Endereço</label>
  <div class="form-group row">
    <br>
    <div class="col-md-3">
      <input type="text" class="form-control" id="inputAddress2" placeholder="Rua" style="background-color: #CCFFDC;" name="rua">
    </div>
    <div class="col-md-3">
      <input type="text" class="form-control" id="inputAddress2" placeholder="Bairro" style="background-color: #CCFFDC;" name="bairro">
    </div>
    <div class="col-md-3">
      <input type="text" class="form-control" id="inputAddress2" placeholder="Complemento" style="background-color: #CCFFDC;" name="complemento">
    </div>
    <div class="col-md-2">
      <input type="text" class="form-control" id="inputAddress2" placeholder="Número" style="background-color: #CCFFDC;" name="numeroEndereco">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity">Cidade</label>
      <input type="text" class="form-control" id="inputCity" style="background-color: #CCFFDC;" name="cidade">
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">Estado</label>
      <select id="inputState" class="form-control" style="background-color: #CCFFDC;" name="estado">
        <option selected>Escolha...</option >
        <option value ="Acre">AC</option>
        <option value="Alagoas">AL</option>
        <option value="Amapá">AP</option>
        <option value="Amazonas">AM</option>
        <option value="Bahia">BA</option>
        <option value="Ceará">CE</option>
        <option value="Distrito Federal">DF</option>
        <option value="Espírito Santo">ES</option>
        <option value="Goiás">GO</option>
        <option value="Maranhão">MA</option>
        <option value="Mato Grosso">MT</option>
        <option value="Mato Grosso do Sul">MS</option>
        <option value="Minas Gerais">MG</option>
        <option value="Pará">PA</option>
        <option value="Paraíba">PB</option>
        <option value="Paraná">PR</option>
        <option value="Pernambuco">PE</option>
        <option value="Piauí">PI</option>
        <option value="Rio Grande do Norte">RN</option>
        <option value="Rio Grande do Sul">RS</option>
        <option value="Rio de Janeiro">RJ</option>
        <option value="Rondônia">RO</option>
        <option value="Roraima">RR</option>
        <option value="Santa Catarina">SC</option>
        <option value="São Paulo">SP</option>
        <option value="Sergipe">SE</option>
        <option value="Tocantins">TO</option>
      </select>
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">CEP</label>
      <input type="text" class="form-control" id="inputZip" style="background-color: #CCFFDC;" name="CEP">
    </div>
  </div>
  <div class="form-group row">
    <div class="form-group col-md-6">
      <label for="formGroupExampleInput">CPF</label>
      <input type="text" class="form-control" id="inputZip" style="background-color: #CCFFDC;" placeholder="MÁX 11 números" name="CPF">
    </div>
    <div class="form-group col-md-6">
      <label for="formGroupExampleInput">RG</label>
      <input type="text" class="form-control" id="inputZip" style="background-color: #CCFFDC;" placeholder="MÁX 9 números" name="RG">
    </div>
  </div>
  <div class="form-group row">
    <div class="col-sm-4">
      <label for="formGroupExampleInput">Telefone</label>
      <input type="text" class="form-control" id="formGroupExampleInput" placeholder="1234567890" style="background-color: #CCFFDC;" name="telefone">
    </div>
    <div class="col-sm-4">
      <label for="formGroupExampleInput">Celular</label>
      <input type="text" class="form-control" id="formGroupExampleInput" placeholder="1234567890" style="background-color: #CCFFDC;" name="celular">
    </div>
  <button type="submit" class="btn btn-light" style="background-color: #CCFFDC;">Cadastrar</button>
  </div>
  </form>
  <?php
       if(isset($_SESSION['CPF'])):
  ?>
  <p style="color: black">Cadastrado com sucesso em CPF: <?php echo $_SESSION['CPFCadastro'];?>!</p> 
  <?php unset($_SESSION['CPFCadastro']);endif ?>    
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</body>

</html>