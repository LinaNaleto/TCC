<?php
	$echo = "";
	$PDO = new PDO("mysql:host=143.106.241.3:3306;dbname=cl19463", "cl19463", "cl*24052004");
	$sql = "SELECT Idoso.nome, Idoso.RG, Assinatura.estadoPlano, Assinatura.idPlano FROM Idoso INNER JOIN Assinatura ON Idoso.rg = Assinatura.RGidoso WHERE Idoso.cpfResponsavel = ".$_SESSION['CPF'];
	$result = $PDO->query( $sql );
	$rows = $result->fetchAll( PDO::FETCH_ASSOC );
	foreach ($rows as $value) {
		$nome = $value['nome'];
		$RG = $value['RG'];
		$estadoPlano = $value['estadoPlano'];
		$idPlano = $value['idPlano'];
		$idPlano .= ' anos';
		if($idPlano	== 0){
			$idPlano = " - ";
		}
		if ($estadoPlano == 'V'){
			$estadoPlano = "Válido";
		}	
		if($estadoPlano	== 'F'){
			$estadoPlano = "Inválido";
		}
		$echo .= "<tr>
					<td>".$nome."</td>
					<td>".$RG."</td>
					<td>".$estadoPlano."</td>
					<td>".$idPlano."</td>
				</tr>
		";
	}
	if(!$result)
	{
    	var_dump( $stmt->errorInfo() );
    	exit();
	}
?>