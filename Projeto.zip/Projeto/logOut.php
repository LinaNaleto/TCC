<?php
 session_start();
 session_destroy();
 header('LOCATION: loginIndex.php');
 exit();