<?php
    session_start();
    if(isset($_POST['login'])){
      $i = 0;
      $login = $_POST['login'];
      $senha  = $_POST['senha'];
      $PDO = new PDO("mysql:host=143.106.241.3:3306;dbname=cl19463", "cl19463", "cl*24052004");
      $sql = ("SELECT * FROM Responsavel WHERE email = '".$login."' AND senha = '".$senha."'");
      $result = $PDO->query( $sql );
      $rows = $result->fetchAll( PDO::FETCH_ASSOC );
      foreach ($rows as $value) {
          $i = 1;
      }
      if($i == 1){
        $_SESSION['login'] = $login;
        $_SESSION['senha'] = $senha;
        $sql = ("SELECT nome,CPF FROM Responsavel WHERE email = '".$login."'");
        $result = $PDO->query( $sql );
        $rows = $result->fetchAll( PDO::FETCH_ASSOC );
        foreach ($rows as $value) {
          $_SESSION['nomeResponsavel'] = $value['nome'];
          $_SESSION['CPF'] = $value['CPF'];
        }
        header('LOCATION: index.php');
      }
      else{
        unset ($_SESSION['login']);
        unset ($_SESSION['senha']);
        echo "Email ou senha incorretos";
      }
    }
  ?>