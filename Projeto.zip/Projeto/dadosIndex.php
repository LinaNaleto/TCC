<!DOCTYPE html>

<html>

<head>

	<script src="https://kit.fontawesome.com/f48515887e.js" crossorigin="anonymous"></script>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">


	<link rel="stylesheet" type="text/css" href="indexcss.css">

	<meta charset="utf-8">

	<title>JKLM Helper</title>
	<style type="text/css">
    body {
      font-family: 'Montserrat', sans-serif;
    }
  </style>

</head>
<?php include 'login.php';
      include 'verificaLogin.php';
      include 'montaTabela.php';
?>
<body style="background-color: lightgrey;">

<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #45c087">
  <a class="navbar-brand" href="index.php">JKLM Helper</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
 
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Início<span class="sr-only">(current)</span></a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">
        Contato
    </a>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Sobre
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Como funciona</a>
          <a class="dropdown-item" href="#">Benefícios</a>
          <a class="dropdown-item" href="#">Onde encontrar?</a>
        </div>
      </li>
      </li>
      <li class="nav-item dropdown">
      	<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Produtos
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="pulseiraIndex.php">Pulseira</a>
          <a class="dropdown-item" href="planoIndex.php">Planos</a>
        </div>
      </li>
      <?php if(!isset($_SESSION['login'])):?>
      <li class="nav-item dropdown" >
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Entrar
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="loginIndex.php" >Logar</a>
          <a class="dropdown-item" href="cadastroIndex.php">Cadastrar-se</a>
        </div>
      </li>
      <?php endif;?>
      <?php if(isset($_SESSION['login'])):?>
      <li class="nav-item dropdown">  
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <?php   echo $_SESSION['nomeResponsavel']?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="cadastroIdosoIndex.php">Cadastrar idoso</a>		
          <a class="dropdown-item" href="dadosIndex.php">Ver meu plano</a>
        </div>
      </li>
      <!--Botao logout -->
      <li class="nav-item" style="margin-top:5px" >
        <form action="logOut.php">  
          <button type="submit"style="background-color: transparent; border-color: transparent;"><i class="fa fa-sign-out" style="font-size:24px; color: white;"></i></button>
        </form>
      </li>
      <?php endif ?>
    </ul>
  </div>
</nav>
<div style="margin-left: 400px">
    <table>
        <tr>
          <th>Nome</th>
          <th>RG</th>
          <th>Estado do Plano</th>
          <th>Tempo de duracao</th>
        </tr>
        <?php echo $echo?>
    </table>
</div>
<div class="rodape" style="position: absolute;">
    <h2>Contatos</h2>
    <ul type="circle">
      <li>Instagram: @jklm_helper</li>
      <li>Email: jklmHelperSAC@outlook.com</li>
      <li>Telefone: (19)3445-6787</li>
  </div>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>