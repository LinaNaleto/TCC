<?php
		include 'login.php';
		if(isset($_POST['RG'])){
			$PDO = new PDO("mysql:host=143.106.241.3:3306;dbname=cl19463", "cl19463", "cl*24052004");
			$sql = "INSERT INTO Idoso(RG,nome,sexo,dataNasc,bairro,rua,numeroEndereco,estado,cidade,planoSaude,cartaoSus,cpfResponsavel) values 
			(".$_POST['RG'].",
			'".$_POST['nome']."',
			'".$_POST['sexo']."',
			".$_POST['dataNasc'].",
			'".$_POST['bairro']."',
			'".$_POST['rua']."',
			".$_POST['numeroEndereco'].",
			'".$_POST['estado']."',
			'".$_POST['cidade']."',
			".$_POST['planoSaude'].",
			".$_POST['cartaoSUS'].",
			".$_SESSION['CPF'].")";
			$stmt = $PDO->prepare( $sql );
			$result = $stmt->execute();
			if ( ! $result )
			{
    			var_dump( $stmt->errorInfo() );
    			exit();
			}
		session_start();
		if(!isset($_SESSION['nomeIdoso'])){
			$_SESSION['nomeIdoso'] = $_POST['nome'];
		}
			header('LOCATION: cadastroIdosoIndex.php');
		}
?>
?>