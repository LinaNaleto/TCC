<?php
		$cmbIdoso = '';
		$PDO = new PDO("mysql:host=143.106.241.3:3306;dbname=cl19463", "cl19463", "cl*24052004");
		$sql = "SELECT * FROM Idoso WHERE cpfResponsavel = ".$_SESSION['CPF'];
		$result = $PDO->query( $sql );
		while ($linha = $result->fetch(PDO::FETCH_ASSOC)) {
			$cmbIdoso .= "<option value=".$linha['RG'].">".$linha['nome']."</option>";
		}
?>