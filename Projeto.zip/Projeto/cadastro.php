<?php
		if(isset($_POST['CPF'])){
			$PDO = new PDO("mysql:host=143.106.241.3:3306;dbname=cl19463", "cl19463", "cl*24052004");
			$sql = "INSERT INTO Responsavel(CPF,nome,RG,CEP,bairro,rua,complemento,numeroEndereco,email,senha,telefone,celular,cidade,estado) values 
			(".$_POST['CPF'].",
			'".$_POST['nome']."',
			".$_POST['RG'].",
			".$_POST['CEP'].",
			'".$_POST['bairro']."',
			'".$_POST['rua']."',
			'".$_POST['complemento']."',
			".$_POST['numeroEndereco'].",
			'".$_POST['email']."',
			'".$_POST['senha']."',
			".$_POST['telefone'].",
			".$_POST['celular'].",
			'".$_POST['cidade']."',
			'".$_POST['estado']."')";
			$stmt = $PDO->prepare( $sql );
			$result = $stmt->execute();
			if ( ! $result )
			{
    			var_dump( $stmt->errorInfo() );
    			exit();
			}
			if(!isset($_SESSION['CPF']))
				$_SESSION['CPFCadastro'] = $_POST['CPF'];
			header('LOCATION: cadastroIndex.php');
		}
?>