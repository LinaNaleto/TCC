<!DOCTYPE html>

<html>

<head>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">


	<link rel="stylesheet" type="text/css" href="partecadastrocss.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<meta charset="utf-8">

	<title>JKLM Helper</title>
  <style type="text/css">
    body {
      font-family: 'Montserrat', sans-serif;
    }
  </style>

</head>
<?php include 'login.php';
?>
<body style="background-color: lightgrey;">

	<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #45c087">
  <a class="navbar-brand" href="index.php">JKLM Helper</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Início</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">
        Contato
        </a>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Sobre
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Como funciona</a>
          <a class="dropdown-item" href="#">Benefícios</a>
          <a class="dropdown-item" href="#">Onde encontrar?</a>
        </div>
        </li>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Produtos
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="pulseiraIndex.php">Pulseira</a>
          <a class="dropdown-item" href="planoIndex.php">Planos</a>
        </div>
      </li>
      <?php if(!isset($_SESSION['login'])):?>
      <li class="nav-item dropdown" >
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Entrar
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="loginIndex.php" >Logar</a>
          <a class="dropdown-item" href="cadastroIndex.php">Cadastrar-se</a>
        </div>
      </li>
      <?php endif;?>
      <?php if(isset($_SESSION['login'])):?>
      <li class="nav-item dropdown">  
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <?php   echo $_SESSION['nomeResponsavel']?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="cadastroIdosoIndex.php">Cadastrar idoso</a>
          <a class="dropdown-item" href="#" >Editar meus dados</a>
          <a class="dropdown-item" href="#">Ver meu plano</a>
        </div>
      </li>
      <!--Botao logout -->
      <li class="nav-item" style="margin-top:5px" >
        <form action="logOut.php">  
          <button type="submit"style="background-color: transparent; border-color: transparent;"><i class="fa fa-sign-out" style="font-size:24px; color: white;"></i></button>
        </form>
      </li>
      <?php endif ?>
    </ul>
  </div>
  </nav>

  <div class="alert alert-light" role="alert">
  Ainda não tem uma conta?  <a href="cadastroIndex.php" class="alert-link">Cadastre-se.</a>. 
</div>
  <?php if(!isset($_SESSION['login'])):?>
	<div class="container" style="background-color: #45C087; padding-bottom: 20px; margin-top: 20px;">
  <form method="post" action="login.php">
    <div class="form-row">
      <div class="form-group col-md-12">
      <label for="inputAddress">Usuário ou email</label>
      <input type="text" class="form-control" id="inputAddress" placeholder="email@mail.com" style="background-color: #CCFFDC;" name = "login">
    </div>
    <div class="form-group col-md-12">
        <label for="inputPassword4">Senha</label>
        <input type="password" class="form-control" id="inputPassword4" placeholder="Senha" style="background-color: #CCFFDC;" name  = "senha">
      </div>
      <div class="form-group row">
      <div class="col-sm-10">
        <button type="submit" class="btn btn-light" style="background-color: #CCFFDC;">Logar</button>
      </div>
    </div>
    </div>
  </form>
  <?php else: ?>
  <div class="container" style="background-color: #45C087; padding-bottom: 20px; margin-top: 20px;text-align: center; color:  white; padding-top: 20px">
    <div class="row">
      <div class="col-md-12">
          <h3> Você já está logado </h3>
          <br>
          <h5>Bem vindo <?php echo $_SESSION['nomeResponsavel']?>!</h5> 
      </div>
    </div>
  </div>
  <?php endif ?>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</body>


</html>