<?php 
	include 'login.php';
	if(isset($_GET['idoso'])){
		$PDO = new PDO("mysql:host=143.106.241.3:3306;dbname=cl19463", "cl19463", "cl*24052004");
		$sql = "INSERT INTO Assinatura(CPFresponsavel,RGidoso,idPlano) VALUES(
		".$_SESSION['CPF'].",
		".$_GET['idoso'].",
		".$_SESSION['idPlano'].")";
		$stmt = $PDO->prepare( $sql );
		$result = $stmt->execute();
		if(!$result)
		{
    		var_dump( $stmt->errorInfo() );
    		exit();
		}
		header('LOCATION: mensagem.php?m=2');
	}
?>