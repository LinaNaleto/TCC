<!DOCTYPE html>

<html>

<head>

	<script src="https://kit.fontawesome.com/f48515887e.js" crossorigin="anonymous"></script>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">


	<link rel="stylesheet" type="text/css" href="indexcss.css">

	<meta charset="utf-8">

	<title>JKLM Helper</title>
	<style type="text/css">
    body {
      font-family: 'Montserrat', sans-serif;
    }
  </style>

</head>
<?php include 'login.php';
?>
<body>

<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #45c087">
  <a class="navbar-brand" href="index.php">JKLM Helper</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
 
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Início<span class="sr-only">(current)</span></a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">
        Contato
    </a>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Sobre
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Como funciona</a>
          <a class="dropdown-item" href="#">Benefícios</a>
          <a class="dropdown-item" href="#">Onde encontrar?</a>
        </div>
      </li>
      </li>
      <li class="nav-item dropdown">
      	<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Produtos
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="pulseiraIndex.php">Pulseira</a>
          <a class="dropdown-item" href="planoIndex.php">Planos</a>
        </div>
      </li>
      <?php if(!isset($_SESSION['login'])):?>
      <li class="nav-item dropdown" >
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Entrar
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="loginIndex.php" >Logar</a>
          <a class="dropdown-item" href="cadastroIndex.php">Cadastrar-se</a>
        </div>
      </li>
      <?php endif;?>
      <?php if(isset($_SESSION['login'])):?>
      <li class="nav-item dropdown">  
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <?php   echo $_SESSION['nomeResponsavel']?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="cadastroIdosoIndex.php">Cadastrar idoso</a>		
          <a class="dropdown-item" href="dadosIndex.php">Ver meu plano</a>
        </div>
      </li>
      <!--Botao logout -->
      <li class="nav-item" style="margin-top:5px" >
        <form action="logOut.php">  
          <button type="submit"style="background-color: transparent; border-color: transparent;"><i class="fa fa-sign-out" style="font-size:24px; color: white;"></i></button>
        </form>
      </li>
      <?php endif ?>
    </ul>
  </div>
  </nav>



<!--FIM NAVBAR ------------------------------------------------------------------------------------------------------------------------------------------>




  <div class="container-fluid" id="bg1">
  	<div class="row">
  	<div class="col-md-12 col-sm-12">
    <div class="jumbotron" id="jumb1">
    <h1 class="display-md-12 display-sm-12">Segurança dentro e fora de casa</h1>
    <p class="lead">Essa simples pulseira providencia segurança e praticidade para sua rotina. Com alertas rápidos e eficientes.</p>
    <i class="fas fa-phone-volume fa-4x" style="padding-left: 30px;" ></i>
    <i class="fas fa-align-right fa-4x" style="padding-left: 30px;"></i>     

    <i class="fas fa-ambulance fa-4x"></i>
  </div>
  </div>
  </div>
  </div>


  <div class="modelos">Sobre nós</div>

  <div class="jumbotron" style="margin-bottom: 0px;">
  <p>Somos um grupo de estudantes do COTIL - Colégio Técnico de Limeira. Estamos desenvolvendo um projeto para ajudar a população através de um pedido da prefeitura.</p>
  <p>Desenvolvemos uma pulseira que tem como objetivo alertar os parentes do usuário caso aconteça uma emergência.</p>
  </div>
  <div class="modelos">Como funciona</div>
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-sm-12">
        <img src="imagens/sw.png"><br>
        <img src="imagens/emergency.jpg"><br>
        <img src="imagens/support.png">
	   </div>
      <div class="col-md-6 col-sm-12">
       <div class="card" id="accordionExample">
		    <div class="card-header" id="headingOne">
		      <h2 class="mb-1">
		        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
		          O relógio
		        </button>
		      </h2>
		    </div>

		    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
		      <div class="card-body">
		        No caso de um acidente, quando sente um choque ou quando apertado, o relógio envia uma notificação de emergência para o telefeone relacionado ao usuário.
		        Seu diferencial é não precisar de terceiros ao envio da emergência para o responsável.
		      </div>
			</div>
			<div class="card" id="accordionExample">
		    <div class="card-header" id="headingOne">
		      <h2 class="mb-1">
		        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
		          Emergência
		        </button>
		      </h2>
		    </div>
		   </div>

		    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
		      <div class="card-body">
		        É ativado um sistema de emergência pré progaramado, acionando uma ambelância para o atendimento mais rápido possível.
		        Dados prévios como idade, tipo sanguíneo e um breve hitórico podem ser enviados.
		      </div>
		</div>
		<div class="card" id="accordionExample">
		    <div class="card-header" id="headingOne">
		      <h2 class="mb-1">
		        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
		          Suporte
		        </button>
		      </h2>
		    </div>

		    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
		      <div class="card-body">
		       Nossa equipe fornecerá uma ferramenta onde será possível registrar todos os acidentes/acontecimentos relacionado ao seu ente querido.
		       Dessa forma tudo poderá ser registrado e documentado.
		     </div>
		 	</div>
	    	</div>
			</div>
   	</div>
	</div>
	</div>

		

		     <div class="modelos" style="margin-bottom: 10px;">Benefícios</div>

			 <div class="container" style="margin-top: 0px;">
			    <div class="jumbotron">
				<div class="bd-example">
					  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
					    <ol class="carousel-indicators">
					      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
					      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
					      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
					    </ol>
					    <div class="carousel-inner">
					      <div class="carousel-item active">
					        <img src="imagens/confiavel.jpg" class="d-block w-100" alt="...">
					        <div class="carousel-caption d-none d-md-block">
					          <h5>Confiança</h5>
					          <p>A JKLM garante a qualidade do seu serviço sendo a pioneira nesse tipo de atendimento</p>
					        </div>
					      </div>
					      <div class="carousel-item">
					        <img src="imagens/idosos.jpg" class="d-block w-100" alt="...">
					        <div class="carousel-caption d-none d-md-block">
					          <h5>Tranquilidade</h5>
					          <p>Não é mais necessário ficar se preocupando com a ausência</p>
					        </div>
					      </div>
					      <div class="carousel-item">
					        <img src="imagens/idosos2.jpg" class="d-block w-100" alt="...">
					        <div class="carousel-caption d-none d-md-block">
					          <h5>Companheirismo</h5>
					          <p>Queremos trazer o maior conforto para sua família!</p>
					        </div>
					      </div>
					    </div>
					    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
					      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
					      <span class="sr-only">Previous</span>
					    </a>
					    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
					      <span class="carousel-control-next-icon" aria-hidden="true"></span>
					      <span class="sr-only">Next</span>
					    </a>
					  </div>
					</div>
				</div>
				</div>

		 <div class="modelos">Experiências</div>

		<div class="row" style="margin-top: 30px; margin-left: 10%;">
			<div class="col-md-4 col-sm-12">
			<img src="imagens/veio2.jpg" class="img-fluid img-thumbnail">
			<div class="card text-white mb-3" style="max-width: 18rem; background-color: #45c087; margin-top: 10px;" >
			  <div class="card-header">Sesbastião</div>
			  <div class="card-body">
			    <p class="card-text">"Me sinto seguro com o relógio, foi nescessário o uso do aparelho e o serviço foi excelente."</p>
			  </div>
			</div>
			</div>

			<div class="col-md-4 col-sm-12">
			<img src="imagens/gui.jpg" class="img-fluid rounded">
			<div class="card text-white mb-3" style="max-width: 18rem; background-color: #45c087; margin-top: 10px;" >
			  <div class="card-header">Guilherme Araújo</div>
			  <div class="card-body">
			    <p class="card-text">"Costumo viajar muito e agora com mais tranquilidade, mesmo assim não deixo de saber como meu pai está."</p>
			  </div>
			</div>
			</div>

			<div class="col-md-4 col-sm-12">
			<img src="imagens/veia1.jpg" class="img-fluid rounded-circle" style="height: 194px;">
			<div class="card text-white mb-3" style="max-width: 18rem; background-color: #45c087; margin-top: 10px;" >
			  <div class="card-header">Ofélia</div>
			  <div class="card-body">
			    <p class="card-text">"Adorei a ideia do produto e não desgrudo dele, posso alertar qualquer problema que eu estiver tendo sozinha em uma situação."</p>
			  </div>
			</div>
         </div> 
        </div>

 	<div class="modelos">Onde estamos</div>

 	<div class="container">
 		<div class="col-md-12">
 		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d921.1104720132815!2d-47.42428487080111!3d-22.562570460616065!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94c8806e90c55133%3A0x515ba5ebf1aca2c0!2sJardim%20Sao%20Paulo%2C%20Limeira%20-%20SP%2C%2013484-332!5e0!3m2!1spt-BR!2sbr!4v1573175080531!5m2!1spt-BR!2sbr" width="50%" height="600" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
 	</div>
 	</div>

 	<div class="rodape">
 		<h2>Contatos</h2>
 		<ul type="circle">
 			<li>Instagram: @jklm_helper</li>
 			<li>Email: jklmHelperSAC@outlook.com</li>
 			<li>Telefone: (19)3445-6787</li>
 	</div> 
            
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<?php 
		session_
	?>
</body>

</html>