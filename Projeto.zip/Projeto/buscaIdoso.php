<?php
	if(isset($_POST['CPF'])){
		$PDO = new PDO("mysql:host=143.106.241.3:3306;dbname=cl19463", "cl19463", "cl*24052004");
		$sql = "SELECT * FROM Idoso WHERE cpfResponsavel = ".$_POST['CPF'];
		$stmt = $PDO->prepare( $sql );
		$result = $stmt->execute();
		$rows = $result->fetchAll( PDO::FETCH_ASSOC );
		foreach ($rows as $value) {
			$print += "<option value='".$value['RG']."'>".$value['nome']."</option>";
		}
	}
?>