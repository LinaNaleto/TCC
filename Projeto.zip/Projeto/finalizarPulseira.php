<?php
	if ((isset($_POST['exampleRadios']))and(isset($_POST['idoso']))) {
		$PDO = new PDO("mysql:host=143.106.241.3:3306;dbname=cl19463", "cl19463", "cl*24052004");
		$sql = "INSERT INTO Pulseira (cor,rgIdoso) VALUES(
			'".$_POST['exampleRadios']."',
			".$_POST['idoso'].")";
		$stmt = $PDO->prepare( $sql );
		$result = $stmt->execute();
		if(!$result)
		{
    		var_dump( $stmt->errorInfo() );
    		exit();
		}
		header('LOCATION: mensagem.php?m=1');
	}
?>